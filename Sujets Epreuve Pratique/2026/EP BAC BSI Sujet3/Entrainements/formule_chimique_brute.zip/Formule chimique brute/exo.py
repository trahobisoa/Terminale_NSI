def dicoAtome(molecule):
    ...
	
eau = "HOH"
dioxygene = "HH"
methane = "HHCHH"
saccharose = "CCCOOOOHHHHCHHOCHHHOOHHHHCCHCCCCCOOOHHHHOHHHH"
dicEau = {"C":0,"H":2,"N":0,"O":1}
diCoxygene = {"C":1,"H":2,"N":2,"O":0} #On fait exprès une erreur ici

assert dicEau == dicoAtome(eau)
assert not diCoxygene == dicoAtome(dioxygene) #Ne passe pas si on enlève le not
assert dicoAtome(saccharose) == {"C":12,"H":22,"N":0,"O":11}

def factoriser(dicoMolecule):
    molecule = ...
    for ...:
        if ... :
            molecule += ...
        elif ...:
            molecule += ...
    return molecule

assert factoriser(dicEau) == "H2O"
assert factoriser(dicoAtome(saccharose)) == "C12H22O11"
assert not factoriser(diCoxygene) == "H2" #Ne passe pas si on enlève le not