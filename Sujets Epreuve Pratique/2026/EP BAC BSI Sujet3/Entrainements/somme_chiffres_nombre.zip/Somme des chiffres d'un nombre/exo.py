#Exercice 1
def somme_chiffres(effectifs_chiffres):
    ...

assert somme_chiffres([0, 0, 0, 0, 0, 0, 0, 0, 0, 0]) == 0
assert somme_chiffres([1, 1, 1, 1, 1, 1, 1, 1, 1, 1]) == 45
assert somme_chiffres([0, 0, 0, 0, 0, 0, 0, 0, 0, 1]) == 9
assert somme_chiffres([0, 9, 0, 0, 0, 0, 0, 0, 0, 0]) == 9

# A decommenter quand les deux exercices sont terminés
# assert somme_chiffres(decomposition(111223)) == 10
# assert somme_chiffres(decomposition(1337 ** 42)) == 595

# Exercice 2
def decomposition(nombre):
    effectifs_chiffres = [0] * ...
    while nombre != ...:
        nombre, unite = ...
        effectifs_chiffres[...] = effectifs_chiffres[...] + 1
    return ...

assert decomposition(0) == [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
assert decomposition(1234567890) == [1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
assert decomposition(111223) == [0, 3, 2, 1, 0, 0, 0, 0, 0, 0]
assert decomposition(312121) == [0, 3, 2, 1, 0, 0, 0, 0, 0, 0]
assert decomposition(10111213141516171819) == [1, 11, 1, 1, 1, 1, 1, 1, 1, 1]
assert decomposition(1337 ** 42) == [18, 13, 15, 8, 14, 9, 12, 8, 16, 19]

def decomposition2(nombre):
    effectifs_chiffres = [0] * ...
    nombre = str(...)
    for ... in ...:
        effectifs_chiffres[...] += 1
    return ...