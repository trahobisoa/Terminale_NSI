﻿### EXERCICE 1 ###

def conv_bin(n) :
	...

assert conv_bin(9) == [0, 0, 0, 0, 1, 0, 0, 1]
assert conv_bin(12) == [0, 0, 0, 0, 1, 1, 0, 0]
assert conv_bin(0) == [0, 0, 0, 0, 0, 0, 0, 0]


### EXERCICE 2 ###

import random
# On utilisera le module randrange en écrivant random.randrange(start, stop+1)

#Réalise l'opérateur OU-exclusif entre deux bits

def xor(a, b):
    if ... :
        return 1
    elif ... :
        return 1
    else :
        return 0

#Crée une clé aléatoire de la même taille que le message
#Entrée : message sous la forme d'une série de bits

def generation_cle(message) :
    longueur = ...
    # création de la clé par compréhension
    cle = ...
    return cle

#Génère une suite de bits à partir d'une chaine de caractères

def message_en_binaire(message):
    message_binaire = []
    for caractere in message :
        message_binaire += conv_bin(ord(caractere))
    return message_binaire

# Convertie un message clair

def cryptage_Vernam(message):

    #on transforme la chaine de caractères en suite de bits
    message_binaire = message_en_binaire(message)
    
	#Génération d'une clé de même longueur
    cle = generation_cle(message_binaire)
    message_crypte = []

    #on réalise le cryptage par une opération bit à bit
    for i in range(len(message_binaire)):
        bit_crypte = ...
        message_crypte...

    return cle, message_crypte

#Convertie un nombre binaire sous 8 bits en entier

def conv_dec(binaire):
    nombre = 0
    for i in range(8):
        exposant = 7 - i
        nombre += binaire[i]*2**exposant
    return nombre

#Dechiffre un message selon le chiffre de Vernam

def decrypt (message, cle):
    decrypt = []
    clair = ""
    for i in range(len(message)):
        bit_decrypte =
        decrypt...

    #Reconstitution du message en caractère
    while (len(decrypt) !=0) :
        mot =[]
        #on reconstitue des listes de 8 mots
        for i in range(8):
            bit = decrypt...
            mot...
        #Puis on convertit la liste de bit en entier puis en caractère
        clair += chr(conv_dec(mot))
    return clair

cle, message_crypte = cryptage_Vernam("NSI")
assert decrypt(message_crypte, cle) == "NSI"