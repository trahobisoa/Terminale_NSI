﻿### EXERCICE 1 ###

#version en divisant par les poids à chaque position
def conv_bin(n) :
    binaire = []
    for i in range(8):
        exposant = 7 - i
        binaire.append(n//(2**exposant))
        n = n%(2**exposant)
    return binaire

#version récursive
def binaire(n):
    if n > 0 :
        return [n%2]+binaire(n//2)
    else :
        return []

def conv_bin2(n) :
    tab_binaire = binaire(n)
    #print(tab_binaire)

    #on complète jusqu'à 8 bits
    while len(tab_binaire) < 8 :
        tab_binaire.append(0)
    tab_binaire.reverse()
    return tab_binaire

#version avec divisions successives de 2
def conv_bin3(n) :
    binaire = []
    while n>0 :
        binaire.append(n%2)
        n = n//2

    #on complète jusqu'à 8 bits
    while len(binaire) < 8 :
        binaire.append(0)
    #print(binaire)
    binaire.reverse()
    #print(binaire)
    return binaire

assert conv_bin(9) == [0, 0, 0, 0, 1, 0, 0, 1]
assert conv_bin2(12) == [0, 0, 0, 0, 1, 1, 0, 0]
assert conv_bin3(0) == [0, 0, 0, 0, 0, 0, 0, 0]

### EXERCICE 2 ###

import random
# On utilisera le module randrange en écrivant random.randrange(start, stop+1)

#Réalise l'opérateur OU-exclusif entre deux bits
def xor(a, b):
    if a == 1 and b==0 :
        return 1
    elif a == 0 and b == 1 :
        return 1
    else :
        return 0

#Crée une clé aléatoire de la même taille que le message
def generation_cle(message) :
    longueur = len(message)
    cle=[random.randrange(0, 2)  for i in range(longueur)]
    return cle

#Génère une suite de bits à partir d'une chaine de caractères
def message_en_binaire(message):
    message_binaire = []
    for caractere in message :
        message_binaire += conv_bin(ord(caractere))
    return message_binaire

# Convertie un message clair
def cryptage_Vernam(message):

    message_binaire = message_en_binaire(message)
    cle = generation_cle(message_binaire)
    message_crypte = []

    for i in range(len(message_binaire)):
        message_crypte.append(xor(message_binaire[i],cle[i]))
    return cle, message_crypte

#Convertie un nombre binaire sous 8 bits en entier
def conv_dec(binaire):
    nombre = 0
    for i in range(8):
        exposant = 7 - i
        nombre += 2**exposant*binaire[i]
    return nombre

def decrypt (message, cle):
    decrypt = []
    clair = ""
    for i in range(len(message)):
        decrypt.append(xor(message[i],cle[i]))
    while (len(decrypt) !=0) :
        mot =[]
        for i in range(8):
            mot.append(decrypt.pop(0))
        clair += chr(conv_dec(mot))
    return clair

cle, message_crypte = cryptage_Vernam("NSI")
assert decrypt(message_crypte, cle) == "NSI"
